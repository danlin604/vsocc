<?php
/**
 * These are the database login details
 */  
define("HOST", "localhost");     // The host you want to connect to.
define("USER", "a2225715_vsocc");    // The database username. 
define("PASSWORD", "your password");    // The database password. 
define("DATABASE", "a2225715_vsocc");    // The database name.
 
define("CAN_REGISTER", "any");
define("DEFAULT_ROLE", "member");
 
define("SECURE", FALSE);    // FOR DEVELOPMENT ONLY!!!!
?>