<?

////////////////////////////////////////////////////////////////////////////// 
//                                                                          //
// IF YOU SEE THIS ON YOUR BROWSER SCREEN, it means that PHP/CGI support    //
// has not been activated for your account. If that's the case, please call //
// your sales rep to add PHP/CGI support.                                   //
//                                                                          //
////////////////////////////////////////////////////////////////////////////// 











































////////////////////////////////////////////////////////////////////////////// 
//                                                                          //
// test.php - sample/test php script.                                       //
//                                                                          //
////////////////////////////////////////////////////////////////////////////// 

	if ($remark != ''){
		echo "
<HTML><BODY BGCOLOR=#3399FF>
<BR><BR><TABLE ALIGN=CENTER BORDER=0 WIDTH=300>
<TR><TD>
<H1> Hello World!</H1>
<FONT SIZE=+1>You said:</FONT>
<TABLE WIDTH=95%><TR BGCOLOR=#DDDDDD><TD><PRE>$remark</PRE></TD></TR></TABLE>
</TD></TR></TABLE>
</BODY></HTML>
		";		
	} else if ($showinfo == ''){
		echo "
<HTML><BODY BGCOLOR=#3399FF>
<BR><BR><TABLE ALIGN=CENTER BORDER=0 WIDTH=300>
<TR><TD>
<H1> Hello World!</H1>
<P>If you can see this, then it means that PHP support for your account is active.
<P>Some test items here:
<P><LI>View the <A HREF='$PHP_SELF?showinfo=1'>PHP Service Info</A> on your server.
<P><LI>Enter some text:
<FORM ACTION='$PHP_SELF' METHOD=POST>
<TEXTAREA NAME='remark' ROWS=5>
</TEXTAREA>
<INPUT TYPE=SUBMIT VALUE=Test>
</FORM>
</TD></TR></TABLE>
</BODY></HTML>
		";
	} else {
		phpinfo();		
	}
?>