vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 Apr 2002 02:44:52 -0000
vti_extenderversion:SR|5.0.2.2623
vti_backlinkinfo:VX|welcome/upload/index.html welcome/upload/ws_ftp.html welcome/upload/cute.html welcome/upload/frontpage.html welcome/scripts/index.html welcome/index.html welcome/TEMPLATE.html
